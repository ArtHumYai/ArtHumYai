package com.example.tproject1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
