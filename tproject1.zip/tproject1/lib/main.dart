import 'package:flutter/material.dart';
import 'package:tproject1/pages/Signfirstpages.dart';
// import 'package:tproject1/pages/home.dart';
import 'package:tproject1/pages/routes.dart';

// import 'package:panulog/src/pages/loginpage.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "MyApp",
      routes: AppRoute.all,
      home: signfirstpagesScreen(),
    );
  }
}
