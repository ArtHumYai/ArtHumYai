import 'package:flutter/material.dart';
// import 'package:tproject1/pages/loginScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tproject1/pages/routes.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class registerScreen extends StatefulWidget {
  const registerScreen({super.key});

  @override
  State<registerScreen> createState() => _registerScreenState();
}

class _registerScreenState extends State<registerScreen> {

  final userID = TextEditingController();
  final password = TextEditingController();
  final fullname = TextEditingController();
  final tell = TextEditingController();
  final address = TextEditingController();

  //   Future get_register() async{
  //   var url = "http://192.168.1.107/panulog/login.php";
  //   var response = await http.post(url as Uri,body: {
  //     "userID" : userID.text,
  //     "password" : password.text
  //   });
  //   var data = json.decode(response.body);
  // if (data == "Error"){
  //   Fluttertoast.showToast(
  //       msg: "This is Center Short Toast",
  //       toastLength: Toast.LENGTH_SHORT,
  //       gravity: ToastGravity.CENTER,
  //       timeInSecForIosWeb: 1,
  //       backgroundColor: Colors.red,
  //       textColor: Colors.white,
  //       fontSize: 16.0
  //   );
  // }else{
  //       Fluttertoast.showToast(
  //       msg: "สมัครข้อมูลเสร็จสิ้น ",
  //       toastLength: Toast.LENGTH_SHORT,
  //       gravity: ToastGravity.CENTER,
  //       timeInSecForIosWeb: 1,
  //       backgroundColor: Colors.red,
  //       textColor: Colors.white,
  //       fontSize: 16.0
  //   );
  // }
  // }
 Future<String> get_register() async {
    Map<String, dynamic> data_post = {
      "userID": userID.text.toString(),
      "password": password.text.toString(),
      "fullname": fullname.text.toString(),
      "tell": tell.text.toString(),
      "address": address.text.toString()
    };

    var uri = Uri.parse("http://192.168.1.107/panulog/register.php");
    var response = await http.post(uri,
        body: json.encode(data_post),
        encoding: Encoding.getByName("utf-8"));
       var data= await json.decode(json.encode(response.body));
     if (data == "Successful") {
        Fluttertoast.showToast(
        msg: "This is Center Short Toast",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0
    );
    } else {
        Fluttertoast.showToast(
        msg: "This is Center Short Toast",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0
    );
    }
    return "ok";
  }

  @override
  void initState() {
    super.initState();
    userID.text = "";
    password.text = "";
  }
    buildButtons() {
    return [
      OutlinedButton(
        onPressed: _handleClickReset,
        child: Text(
          "RESET",
          style: TextStyle(
            fontSize: 10,
            color: Color.fromARGB(255, 255, 255, 255),
            
          ),
          
      ),
      ),
    ];
    
  }
  void _handleClickReset() {
    userID.text = "";
    password.text = "";
  }


  Widget textEngREGISTER() {
    return Container(
        child: Text(
          "REGISTER",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontFamily: "",
          ),
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }

  Widget textThaiREGISTER() {
    return Container(
        child: Text(
          "สมัครสมาชิก",
          style: TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontFamily: "",
          ),
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }

  Widget ReusernameInput() {
    return Container(
      child: TextFormField(
        controller: userID,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.person),
            labelText: "username",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget RepasswordInput() {
    return Container(
      child: TextFormField(
        controller: password,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.key),
            labelText: "password",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }
    Widget RefullnameInput() {
    return Container(
      child: TextFormField(
        controller: fullname,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.perm_contact_cal_outlined),
            labelText: "ชื่อ-นามสกุล",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget RetellInput() {
    return Container(
      child: TextFormField(
        controller: tell,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.phone_in_talk),
            labelText: "เบอร์โทร",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget ReAddreesInput() {
    return Container(
      child: TextFormField(
        controller: address,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.place),
            labelText: "ที่อยู่",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget or() {
    return Container(
        child: Text(
          "_______________________________________  or  _______________________________________",
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w900,
            color: Color.fromARGB(255, 113, 172, 255),
          ),
          
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }


  Widget signUPbutton() {
    return Container(
      child: ElevatedButton(
        onPressed: () {
          get_register();
        },
        child: Text(
          "SIGN UP",
          style: TextStyle(
            fontSize: 20,
            color: Color.fromARGB(255, 0, 104, 201),
          ),
        ),
        style: ElevatedButton.styleFrom(
          elevation: 5,
          primary: Color.fromARGB(255, 255, 255, 255),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
      ),
      height: 60,
      width: 350,
    );
  }


  Widget backLoginbutton() {
    return Container(
      child: ElevatedButton(
        onPressed: () {
          print("Goooooo"); // get_login();
          Navigator.pushNamed(context, AppRoute.login);
        },
        child: Text(
          "กลับไปหน้าล็อกอิน",
          style: TextStyle(
            fontSize: 20,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          elevation: 10,
          primary: Color.fromARGB(255, 0, 81, 255),
                    shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
      ),
      height: 60,
      width: 350,
    );
  }
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("images/screen/background.jpg"),
                fit: BoxFit.cover)),
      ),
      Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
              child: Center(
                  child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
     
              SizedBox(height: 50),
              textThaiREGISTER(),
              textEngREGISTER(),
              
              SizedBox(height: 10),
              ReusernameInput(),
              SizedBox(height: 10),
              RepasswordInput(),
              SizedBox(height: 10),
              RefullnameInput(),
              SizedBox(height: 10),
              RetellInput(),
              SizedBox(height: 10),
              ReAddreesInput(),
              ...buildButtons(),
              
              or(),
              
              SizedBox(height: 20),
              signUPbutton(),
              SizedBox(height: 10),
              backLoginbutton(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [],
              ),
            ],
          ))))
    ]);
  }
}
