import 'package:flutter/material.dart';
import 'package:tproject1/pages/home.dart';
// import 'package:tproject1/pages/home.dart';
import 'package:tproject1/pages/routes.dart';
// import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class loginScreen extends StatefulWidget {
  const loginScreen({super.key});

  @override
  State<loginScreen> createState() => _loginScreenState();
}

class _loginScreenState extends State<loginScreen> {

  TextEditingController userID = TextEditingController();
  TextEditingController password = TextEditingController();

Future<String> get_login() async {
    Map<String, String> headers = {
      "content-type": "application/json",
      "accept": "application/json"
    };

    Map<String, String> data_post = {
      "username": userID.text.toString(),
      "password": password.text.toString()
    };

    var uri = Uri.parse("http://192.168.1.107/panulog/login.php");
    var response = await http.post(uri,
        headers: headers,
        body: json.encode(data_post),
        encoding: Encoding.getByName("utf-8"));

    Map resp_json = json.decode(response.body);
    print(resp_json);
    print(resp_json["result"]);

    if (int.parse(resp_json["result"]) == 1) {
      print("next page");
      Navigator.of(this.context)
          .push(MaterialPageRoute(builder: (context) => homeScreen()));
      userID.clear();
      password.clear();
      print(resp_json["dataList"][0]["cus_name"]);
    } else {
      print("Login false");
    }
    return "OK";
  }

  // Future get_login() async{
  //   var url = "http://192.168.1.107/panulog/login.php";
  //   var response = await http.post(url,body: {
  //     "userID" : userID.text,
  //     "password" : password.text
  //   });
  //   var data = json.decode(response.body);
  // if (data == "Error"){
  //   Fluttertoast.showToast(
  //       msg: "This is Center Short Toast",
  //       toastLength: Toast.LENGTH_SHORT,
  //       gravity: ToastGravity.CENTER,
  //       timeInSecForIosWeb: 1,
  //       backgroundColor: Colors.red,
  //       textColor: Colors.white,
  //       fontSize: 16.0
  //   );
  // }else{
  //       Fluttertoast.showToast(
  //       msg: "สมัครข้อมูลเสร็จสิ้น ",
  //       toastLength: Toast.LENGTH_SHORT,
  //       gravity: ToastGravity.CENTER,
  //       timeInSecForIosWeb: 1,
  //       backgroundColor: Colors.red,
  //       textColor: Colors.white,
  //       fontSize: 16.0
  //   );
  // }
  // }
  

  // Future<String> get_login() async {
  //   Map<String, String> headers = {
  //     "content-type": "application/json",
  //     "accept": "application/json"
  //   };

  //   Map<String, String> data_post = {
  //     "username": userID.text.toString(),
  //     "password": password.text.toString(),
  //   };

  //   var uri = Uri.parse("http://192.168.1.107/panulog/login.php");
  //   var response = await http.post(uri,
  //       headers: headers,
  //       body: json.encode(data_post),
  //       encoding: Encoding.getByName("utf-8"));
  //   Map resp_json = json.decode(response.body);
  //   print(resp_json);
  //   // print(resp_json["result"]);
  //   print(resp_json["datalist"][0]["cus_name"]);
  //   if (resp_json["result"] == 1) {
  //     print("Login Fall");
  //   } else {
  //     print("next page");
  //     Navigator.of(context)
  //         .push(MaterialPageRoute(builder: (context) => homeScreen()));
  //   }
  //   return "Okey";
  // }

 
  Widget applogo2() {
    return Container(
      width: 500,
      height: 250,
      child: Image.asset('images/logo/logo2White.png'),
      margin: EdgeInsets.fromLTRB(50, 80, 50, 0),
    );
  }

  Widget textEng() {
    return Container(
        child: Text(
          "LOGIN",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontFamily: "",
          ),
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }

  Widget textThai() {
    return Container(
        child: Text(
          "เข้าสู่ระบบ",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontFamily: "",
          ),
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }

  Widget usernameInput() {
    return Container(
      child: TextFormField(
        controller: userID,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.person),
            labelText: "username",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget passwordInput() {
    return Container(
      child: TextFormField(
        obscureText: true,
        controller: password,
        decoration: InputDecoration(
            prefixIcon: Icon(Icons.key),
            labelText: "password",
            filled: true,
            fillColor: Colors.white,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(15))),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
    );
  }

  Widget or() {
    return Container(
        child: Text(
          "_______________________________________  or  _______________________________________",
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w900,
            color: Color.fromARGB(255, 113, 172, 255),
          ),
          
        ),
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0));
  }

  Widget signINbutton() {
    return Container(
      child: ElevatedButton(
        onPressed: () {
          get_login();
        },
        child: Text(
          "SIGN IN",
          style: TextStyle(
            fontSize: 20,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          elevation: 10,
          primary: Color.fromARGB(255, 0, 81, 255),
                    shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
      ),
      height: 60,
      width: 350,
    );
  }

  Widget GotosignUPbutton() {
    return Container(
      child: ElevatedButton(
        onPressed: () {
          print("Goooooo"); // get_login();
          Navigator.pushNamed(context, AppRoute.register);
        },
        child: Text(
          "SIGN UP",
          style: TextStyle(
            fontSize: 20,
            color: Color.fromARGB(255, 0, 104, 201),
          ),
        ),
        style: ElevatedButton.styleFrom(
          elevation: 5,
          primary: Color.fromARGB(255, 255, 255, 255),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
      ),
      height: 60,
      width: 350,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("images/screen/background.jpg"),
                fit: BoxFit.cover)),
      ),
      Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
              child: Center(
                  child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              applogo2(),
              SizedBox(height: 20),
              textEng(),
              textThai(),
              SizedBox(height: 20),
              usernameInput(),
              SizedBox(height: 20),
              passwordInput(),
              SizedBox(height: 20),
              or(),
              SizedBox(height: 20),
              signINbutton(),
              SizedBox(height: 10),
              GotosignUPbutton(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [],
              ),
            ],
          ))))
    ]);
  }
}
