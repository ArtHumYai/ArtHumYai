import 'package:flutter/material.dart';
import 'package:tproject1/pages/routes.dart';
// import 'dart:async';
// import 'dart:convert';

class signfirstpagesScreen extends StatefulWidget {
  const signfirstpagesScreen({super.key});

  @override
  State<signfirstpagesScreen> createState() => _signfirstpagesScreenState();
}

class _signfirstpagesScreenState extends State<signfirstpagesScreen> {
  Widget applogo() {
    return Container(
      width: 500,
      height: 250,
      child: Image.asset('images/logo/logoWhite1.png'),
      margin: EdgeInsets.fromLTRB(50, 20, 50, 0),
    );
  }

  Widget appName() {
    return Container(
      child: Text(
        "WELCOME",
        style: TextStyle(
          fontSize: 55,
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontFamily: "",
        ),
      ),
      margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
    );
  }

  Widget namedetail() {
    return Container(
      child: Text(
        "BOOKING & FISHING SHOP ",
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontFamily: "",
        ),
      ),
      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
    );
  }

  Widget singbutton() {
    return Container(
      child: ElevatedButton(
        onPressed: () {
          print("Goooooo"); // get_login();
          Navigator.pushNamed(context, AppRoute.login);
        },
        child: Text(
          "SIGN IN",
          style: TextStyle(
            fontSize: 25,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          elevation: 5,
          primary: Color.fromARGB(119, 255, 255, 255),
        ),
      ),
      height: 45,
      width: 175,
      margin: EdgeInsets.fromLTRB(0, 200, 0, 0),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/screen/background.jpg"),
                  fit: BoxFit.cover)),
        ),
        Scaffold(
            backgroundColor: Colors.transparent,
            body: SafeArea(
                child: Center(
                    child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                applogo(),
                appName(),
                namedetail(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    singbutton(),
                  ],
                ),
              ],
            ))))
      ],
    );
  }
}
