import 'package:flutter/material.dart';

class homeScreen extends StatefulWidget {
  const homeScreen({super.key});

  @override
  State<homeScreen> createState() => _homeScreenState();
}

class _homeScreenState extends State<homeScreen> {


  Widget buttonOut (){
    return Container(
      child: ElevatedButton(
        onPressed: (){

        }
      , 
      child: Text(
        "LOGOUT",
        style: TextStyle(
          fontSize: 20,
        ),
        ),
        style: ElevatedButton.styleFrom(

        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        buttonOut(),
        Scaffold(
          
        )
      ],
    );
    // return MaterialApp(
    //   home: Scaffold(
    //     appBar: 
    //     AppBar(
    //       title: const Text('data'),
    //     ),
        
        // children: [
        //   buttonOut(),
        // ],
    //   ),
    // );
  }
}