import 'package:flutter/cupertino.dart';
import 'package:tproject1/pages/home.dart';
import 'package:tproject1/pages/loginScreen.dart';
import 'package:tproject1/pages/registerScreen.dart';
import 'package:tproject1/pages/signfirstpages.dart';
// import 'home/home_page.dart';
// import 'login/loginpage.dart';

class AppRoute {
  static const String signfirstpages = '/signfirstpages';
  static const String login = '/login';
  static const String home = '/home';
  static const String register = '/register';

  static get all => <String, WidgetBuilder>{
        signfirstpages: (context) => const signfirstpagesScreen(),
        login: (context) => const loginScreen(),
        home: (context) => const homeScreen(),
        register: (context) => const registerScreen(),
        
  
  };
}
